[size=20pt]OneAll Social Login[/size]

OneAll Social Login for SMF 2.1+ is a professional modification that allows
your visitors to login and register with 40+ social networks like for example
Facebook, Twitter, LinkedIn, Google+, LiveJournal, StackExchange and Yahoo 
amongst others.


[b]Social Login increases your registration rate[/b]
Social Login helps increasing your user registration rate by simplifying the
registration process and provides permission-based social data retrieved from
the social network profiles.


[b]Social Login integrates with your existing system[/b]
OneAll Social Login integrates with your existing registration system so you
and your users don't have to start from scratch.


[b]40+ Supported Social Networks[/b]
- Apple
- Amazon
- Battle.net
- Blogger
- Discord 
- Disqus
- Draugiem
- Dribbble
- Epic Games
- Facebook
- Foursquare
- Github.com
- Google
- Instagram
- Line
- LinkedIn
- LiveJournal
- Mail.ru
- Meetup
- Mixer
- Odnoklassniki
- OpenID
- Patreon
- PayPal
- Pinterest
- PixelPin 
- Reddit
- Skyrock.com
- SoundCloud        
- Spotify
- StackExchange
- Steam
- Strava
- Tumblr
- Twitch.tv
- Twitter
- Vimeo
- VKontakte
- Weibo
- Windows Live
- WordPress.com
- XING
- Yahoo
- Yandex
- YouTube


[b]About Us[/b]
Social Login is maintained by OneAll, a technology company offering a set of
web-delivered tools and services for establishing and optimizing a site's 
connection with social networks.


[b]Visit us at:[/b]
http://www.oneall.com


[b]Need help?[/b]
The Social Login documentation is available at:
http://docs.oneall.com/plugins/guide/social-login-smf/

We are devoted to creating a positive experience for our customers and always
try to go above and beyond your expectations. Do not hesitate to contact us for
questions about the Social Login Module, to give us your feedback or if you 
need any help with the integration of the modification.

Our team answers your questions at:
http://support.oneall.com/
http://www.oneall.com/company/contact-us/